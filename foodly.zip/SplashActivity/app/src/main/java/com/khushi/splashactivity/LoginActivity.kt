package com.khushi.splashactivity

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class LoginActivity : AppCompatActivity() {
    lateinit var etmobile:EditText
    lateinit var etpw:EditText
    lateinit var btnlogin:Button
    lateinit var txtforgot:TextView
    lateinit var txtsignup:TextView
    lateinit var sharedPreferences:SharedPreferences
    val validnum="0123456789"
    val validpw="abcdefg"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        etmobile=findViewById(R.id.etmobile)
        etpw=findViewById(R.id.etpw)
        btnlogin=findViewById(R.id.btnlogin)
        txtforgot=findViewById(R.id.txtforgot)
        txtsignup=findViewById(R.id.txtsignup)
        var enterednum=etmobile.text.toString()
        var enteredpw=etpw.text.toString()
        sharedPreferences =
            getSharedPreferences(getString(R.string.preference_file_name), Context.MODE_PRIVATE)
        txtsignup.setOnClickListener { intent= Intent(this@LoginActivity,RegistrationActivity::class.java)
            startActivity(intent) }
        txtforgot.setOnClickListener { intent= Intent(this@LoginActivity,ForgotPasswordActivity::class.java)
        startActivity(intent)}
    }

}